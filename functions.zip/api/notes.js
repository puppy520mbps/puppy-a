const STORE_KEY = "shared-notes-board-v1";
const EMPTY_TEXT = "#新点子";

function createId() {
  return Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
}

function normalizeModules(list) {
  const source = Array.isArray(list) ? list : [];
  const clean = source
    .filter((item) => item && typeof item === "object")
    .map((item) => ({
      id: String(item.id || createId()),
      text: String(item.text ?? "")
    }));

  const nonEmptyNotes = clean.filter((item) => item.text.trim() !== EMPTY_TEXT);
  const existingEmpty = clean.find((item) => item.text.trim() === EMPTY_TEXT);

  nonEmptyNotes.push({
    id: existingEmpty?.id || createId(),
    text: EMPTY_TEXT
  });

  return nonEmptyNotes;
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store"
    }
  });
}

export async function onRequestGet(context) {
  const { env } = context;

  if (!env.NOTES_KV) {
    return jsonResponse({ error: "KV binding NOTES_KV is missing." }, 500);
  }

  const saved = await env.NOTES_KV.get(STORE_KEY, "json");

  if (!saved || !Array.isArray(saved.modules)) {
    const initial = {
      modules: normalizeModules([{ id: createId(), text: EMPTY_TEXT }]),
      updatedAt: Date.now()
    };
    await env.NOTES_KV.put(STORE_KEY, JSON.stringify(initial));
    return jsonResponse(initial);
  }

  const normalized = {
    modules: normalizeModules(saved.modules),
    updatedAt: Number(saved.updatedAt || Date.now())
  };

  return jsonResponse(normalized);
}

export async function onRequestPost(context) {
  const { request, env } = context;

  if (!env.NOTES_KV) {
    return jsonResponse({ error: "KV binding NOTES_KV is missing." }, 500);
  }

  let body;
  try {
    body = await request.json();
  } catch (error) {
    return jsonResponse({ error: "Invalid JSON body." }, 400);
  }

  const modules = normalizeModules(body.modules);
  const payload = {
    modules,
    updatedAt: Date.now()
  };

  await env.NOTES_KV.put(STORE_KEY, JSON.stringify(payload));

  return jsonResponse(payload);
}
